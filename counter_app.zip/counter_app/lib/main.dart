import 'package:flutter/material.dart';
import 'package:get/get.dart';

void main() {
  runApp(MyApp());
}

class CounterController extends GetxController {
  var counter = 0.obs; // obs stands for observable

  void increment() {
    counter++;
  }

  void decrement() {
    counter--;
  }
}

class MyApp extends StatelessWidget {
  final CounterController _counterController = Get.put(CounterController());

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        hintColor: Colors.green,
        buttonTheme: const ButtonThemeData(
          buttonColor: Colors.green,
          textTheme: ButtonTextTheme.primary,
        ),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('GetX Counter App'),
          backgroundColor: Colors.blue, // Colored background for the app bar
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue, Colors.green], // Gradient background colors
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Obx(() => Text(
                  'Counter: ${_counterController.counter}',
                  style: TextStyle(fontSize: 24, color: Colors.white), // Text color
                )),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () => _counterController.increment(),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white, primary: Colors.green, // Text color
                      ),
                      child: const Text('Increment'),
                    ),
                    const SizedBox(width: 16),
                    ElevatedButton(
                      onPressed: () => _counterController.decrement(),
                      style: ElevatedButton.styleFrom(
                        primary: Colors.red, // Button color
                        onPrimary: Colors.white, // Text color
                      ),
                      child: const Text('Decrement'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
